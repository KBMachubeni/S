/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package smserver;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import sminterface.Supplier;

/**
 *
 * @author Karabo Machubeni
 */
public class SMSERVER extends UnicastRemoteObject implements sminterface.SMINTERFACE {


    public SMSERVER() throws RemoteException {
        super();
    }

    /**
     * @param args the command line arguments
     * @throws java.rmi.RemoteException
     */
    public static void main(String[] args) throws RemoteException {

        Registry reg= LocateRegistry.createRegistry(1060);
        reg.rebind("Server", new SMSERVER());
        System.out.println("Server is running");
    }

    private static SMSERVER jdbc;

    public static SMSERVER getInstance() throws RemoteException {
        if (jdbc == null) {
            jdbc = new SMSERVER();
        }
        return jdbc;
    }

    public static Connection getConnection() throws RemoteException {

        Connection connect = null;
        String url = "jdbc:mysql://localhost:3306/stationery?allowMultiQueries=true&rewriteBatchedStatements=true";

        try {
            Class.forName("com.mysql.jdbc.Driver");

            connect = DriverManager.getConnection(url, "root", "");
            //PROOF FOR CUSTOM EXCEPTION
            //  connect = null;
            if (connect != null) {
                System.out.println("DB OPEN!!!");
            } else {
                throw new CustomException("NO CONNECTECTION ESTABLISHED");
            }

        } catch (ClassNotFoundException | SQLException | CustomException ex) {
            System.out.println(ex.getMessage());
        }
        return connect;
    }

    @Override
    public List<Supplier> getSuppliers() throws RemoteException {

        Connection con = getConnection();
        PreparedStatement ps = null;

        List<Supplier> supplier = new ArrayList();

        try {
            ps = con.prepareStatement("SELECT `sup_name`, `sup_contact`, `sup_address` FROM `supplier` ");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
               Supplier suppliers= new Supplier(rs.getString(1), rs.getString(2), rs.getString(3));
               supplier.add(suppliers);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return supplier;
    }
    
    
    
    
}
