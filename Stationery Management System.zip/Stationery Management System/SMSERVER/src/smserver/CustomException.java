/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package smserver;

/**
 *
 * @author Karabo Machubeni
 */
public class CustomException extends Exception{

    public CustomException() {
    }

    public CustomException(String string) {
        super(string);
    }

    public CustomException(String string, Throwable thrwbl) {
        super(string, thrwbl);
    }

    public CustomException(Throwable thrwbl) {
        super(thrwbl);
    }
    
    
}
