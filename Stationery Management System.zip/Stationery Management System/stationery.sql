-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 31, 2018 at 10:40 AM
-- Server version: 5.7.14
-- PHP Version: 7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stationery`
--

-- --------------------------------------------------------

--
-- Table structure for table `administrator`
--

CREATE TABLE `administrator` (
  `a_id` int(11) NOT NULL,
  `a_name` text NOT NULL,
  `a_username` text NOT NULL,
  `a_password` text NOT NULL,
  `a_contact` text NOT NULL,
  `salt` text NOT NULL,
  `securePass` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `administrator`
--

INSERT INTO `administrator` (`a_id`, `a_name`, `a_username`, `a_password`, `a_contact`, `salt`, `securePass`) VALUES
(1, 'Karabo', 'Karabo', 'Karabo', 'Karabo.machubeni@gmail.com', '', '0'),
(2, 'Machubeni Karabo', 'Kb', 'Kb', 'Kb@gmail.com', 'J6rhC3A26PYZ2JEJMKblVQTMDztaKN', 'Ko2cAIbD0F+2TsOnvZMPGNnIdDvhtnJ/n5eUpGm6X24=');

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `stuff_id` int(11) NOT NULL,
  `stuff_name` text NOT NULL,
  `stuff_type` text NOT NULL,
  `stuff_location` text NOT NULL,
  `stuff_deptname` text NOT NULL,
  `stuff_contact` text NOT NULL,
  `stuff_username` text NOT NULL,
  `stuff_password` text NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`stuff_id`, `stuff_name`, `stuff_type`, `stuff_location`, `stuff_deptname`, `stuff_contact`, `stuff_username`, `stuff_password`, `status`) VALUES
(4, 'Phi', 'Part Time', 'Phi', 'Engineering', 'Engineering', 'Kb', 'Kb', 'Accept'),
(6, 'Kb', 'Full Time', 'Lambda', 'Computer', 'Kn@gmail.com', 'Ln', 'Kn', 'Pending'),
(7, 'Karabs', 'Part Time', 'Lambda', 'Computer', 'Karabs@gmail.com', 'Karabo', 'Karabo', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `or_id` int(11) NOT NULL,
  `or_date` date NOT NULL,
  `pr_id` int(11) NOT NULL,
  `pr_qty` int(11) NOT NULL,
  `a_id` int(11) NOT NULL,
  `s_id` int(11) NOT NULL,
  `sup_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `pr_id` int(11) NOT NULL,
  `pr_name` text NOT NULL,
  `pr_amount` text NOT NULL,
  `quantity` int(11) NOT NULL,
  `pr_category` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pr_id`, `pr_name`, `pr_amount`, `quantity`, `pr_category`) VALUES
(1, 'Tablet', '1200.0', 20, 'Electronics'),
(2, 'Bic', '50', 50, ''),
(3, '32 Page Book', '10', 100, ''),
(4, 'Board Pens', '60.0', 4, 'Pens');

-- --------------------------------------------------------

--
-- Table structure for table `requisition`
--

CREATE TABLE `requisition` (
  `r_id` int(11) NOT NULL,
  `r_date` date NOT NULL,
  `pr_id` int(11) NOT NULL,
  `pr_qty` int(11) NOT NULL,
  `s_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `requisition`
--

INSERT INTO `requisition` (`r_id`, `r_date`, `pr_id`, `pr_qty`, `s_id`) VALUES
(4, '2018-10-31', 1, 3, 7),
(5, '2018-10-31', 2, 4, 7);

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `sup_id` int(11) NOT NULL,
  `sup_name` text NOT NULL,
  `sup_contact` text NOT NULL,
  `sup_address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`sup_id`, `sup_name`, `sup_contact`, `sup_address`) VALUES
(1, 'PEN SUPPLIER', '087156626', '723 NGCOBO,STREET,1755'),
(2, 'ELECTRONICS SUPPLIER', '0875558655', '4TH AVENUE, PRETORIA,0201');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administrator`
--
ALTER TABLE `administrator`
  ADD PRIMARY KEY (`a_id`),
  ADD KEY `a_id` (`a_id`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`stuff_id`),
  ADD KEY `stuff_id` (`stuff_id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`or_id`),
  ADD KEY `or_id` (`or_id`),
  ADD KEY `sup_id` (`sup_id`),
  ADD KEY `s_id` (`s_id`),
  ADD KEY `a_id` (`a_id`),
  ADD KEY `pr_id` (`pr_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`pr_id`);

--
-- Indexes for table `requisition`
--
ALTER TABLE `requisition`
  ADD PRIMARY KEY (`r_id`),
  ADD KEY `s_id` (`s_id`),
  ADD KEY `pr_id` (`pr_id`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`sup_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `administrator`
--
ALTER TABLE `administrator`
  MODIFY `a_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `faculty`
--
ALTER TABLE `faculty`
  MODIFY `stuff_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `or_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `pr_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `requisition`
--
ALTER TABLE `requisition`
  MODIFY `r_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `sup_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `order`
--
ALTER TABLE `order`
  ADD CONSTRAINT `order_ibfk_1` FOREIGN KEY (`sup_id`) REFERENCES `supplier` (`sup_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `order_ibfk_2` FOREIGN KEY (`pr_id`) REFERENCES `product` (`pr_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `order_ibfk_3` FOREIGN KEY (`a_id`) REFERENCES `administrator` (`a_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `order_ibfk_4` FOREIGN KEY (`s_id`) REFERENCES `faculty` (`stuff_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `requisition`
--
ALTER TABLE `requisition`
  ADD CONSTRAINT `requisition_ibfk_1` FOREIGN KEY (`pr_id`) REFERENCES `product` (`pr_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `requisition_ibfk_2` FOREIGN KEY (`s_id`) REFERENCES `faculty` (`stuff_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
