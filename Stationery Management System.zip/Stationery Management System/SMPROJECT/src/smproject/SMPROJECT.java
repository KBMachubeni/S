/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package smproject;
import BUSINESS_LOGIC_LAYER.ThreadClass;
import DATA_ACCESS_LAYER.DBConnection;
import PRESENTATION_LAYER.*;
import java.rmi.RemoteException;
/**
 *
 * @author Karabo Machubeni
 */
public class SMPROJECT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)  {
        // TODO code application logic here
        DBConnection.getInstance();
      //  DBConnection.getConnection();
       
        ThreadClass tclass= new ThreadClass();
        Thread t= new Thread(tclass);
        t.start();
        
        
      
        
        
    }
    
}
