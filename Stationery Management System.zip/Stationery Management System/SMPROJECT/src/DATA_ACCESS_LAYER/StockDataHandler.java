/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DATA_ACCESS_LAYER;

import BUSINESS_LOGIC_LAYER.*;
import BUSINESS_LOGIC_LAYER.Products;
import DATA_ACCESS_LAYER.DBConnection;
import static DATA_ACCESS_LAYER.UserDataHandler.ps;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Karabo Machubeni
 */
public class StockDataHandler {

    static Connection con = DBConnection.getConnection();
    static PreparedStatement ps = null;

    public static List<Products> selectStock() {
        List<Products> stocks = new ArrayList();
        try {
            ps = con.prepareStatement("SELECT `pr_name`, `pr_amount`, `quantity`, `pr_category` FROM `product` ");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Products stock = new Products(rs.getString(1), rs.getDouble(2), rs.getInt(3), rs.getString(4));
                stocks.add(stock);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return stocks;
    }

    public static boolean deleteStock(Products products) {
        boolean state = false;
        try {
            ps = con.prepareStatement("DELETE FROM `product` WHERE `pr_id`=?");
            ps.setInt(1, products.getProduct_Id());
            if (ps.executeUpdate() > 0) {
                state = true;
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return state;
    }

    public static boolean insertStock(Products product) {
        boolean state = false;
        try {
            ps = con.prepareStatement("INSERT INTO `product`( `pr_name`, `pr_amount`, `quantity`, `pr_category`) VALUES (?,?,?,?)");

            ps.setString(1, product.getProduct_Name());
            ps.setDouble(2, product.getProduct_Amount());
            ps.setInt(3, product.getQuantity());
            ps.setString(4, product.getCategory());
            if (ps.executeUpdate() > 0) {
                state = true;
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return state;
    }
    
    

    public static List<Products> viewStock() {
        List<Products> stocks = new ArrayList();
        try {
            ps = con.prepareStatement("SELECT `pr_id` ,`pr_name`, `pr_amount`,`pr_category` FROM `product` ");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Products stock = new Products(rs.getInt(1), rs.getString(2), rs.getDouble(3), rs.getString(4));
                stocks.add(stock);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return stocks;
    }
    
    public static List<Products> viewStockUser(String category) {
        List<Products> stocks = new ArrayList();
        try {
            ps = con.prepareStatement("SELECT `pr_id` ,`pr_name`, `pr_amount`,`pr_category` FROM `product` where `pr_category` =?");
            ps.setString(1, category);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Products stock = new Products(rs.getInt(1), rs.getString(2), rs.getDouble(3), rs.getString(4));
                stocks.add(stock);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return stocks;
    }

    public static List<Products> viewStock(String category) {
        List<Products> stocks = new ArrayList();
        try {
            ps = con.prepareStatement("SELECT `pr_name`, `pr_amount`, `quantity`, `pr_category` FROM `product` where `pr_category` =? ");
            ps.setString(1, category);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Products stock = new Products(rs.getString(1), rs.getDouble(2), rs.getInt(3), rs.getString(4));
                stocks.add(stock);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return stocks;
    }
    
    
     public static boolean UpdateStock(Products product) {

        boolean state = false;
        try {
            ps = con.prepareStatement("UPDATE `product` SET `pr_name`=?,`pr_amount`=?,`quantity`=?,`pr_category`=? WHERE `pr_id`=?");
            ps.setString(1, product.getProduct_Name());
            ps.setDouble(2,product.getProduct_Amount());
            ps.setInt(3,product.getQuantity());
            ps.setString(4,product.getCategory());
            ps.setInt(5, product.getProduct_Id());
           
            if (ps.executeUpdate() > 0) {
                state = true;
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());

        }

        return state;
    }

}
