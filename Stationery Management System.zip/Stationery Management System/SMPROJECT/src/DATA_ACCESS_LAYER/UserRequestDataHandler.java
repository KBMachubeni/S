/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DATA_ACCESS_LAYER;

import BUSINESS_LOGIC_LAYER.Requisition;
import DATA_ACCESS_LAYER.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Karabo Machubeni
 */
public class UserRequestDataHandler {

    static Connection con = DBConnection.getConnection();
    static PreparedStatement ps = null;

    public static List<Requisition> selectRequested(int stuff_id) {
        List<Requisition> requestList = new ArrayList();
        try {
            ps = con.prepareStatement("SELECT `r_id`, `r_date`, `pr_id`, `pr_qty` FROM `requisition` WHERE `s_id`=?");
            ps.setInt(1, stuff_id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Requisition request = new Requisition(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4));
                requestList.add(request);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return requestList;
    }
    
    public static List<Requisition> selectRequested() {
        List<Requisition> requestList = new ArrayList();
        try {
            ps = con.prepareStatement("SELECT `r_id`, `r_date`, `pr_id`, `pr_qty`, `s_id` FROM `requisition`");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Requisition request= new Requisition(rs.getInt(1),rs.getString(2),rs.getInt(5),rs.getInt(3),rs.getInt(4));
                requestList.add(request);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return requestList;
    }

    public static boolean deleteRequest(Requisition request) {
        boolean state = false;
        try {
            ps = con.prepareStatement("DELETE FROM `requisition` WHERE `r_id`=?");
            ps.setInt(1, request.getProduct_Id());
            if (ps.executeUpdate() > 0) {
                state = true;
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return state;
    }

    public static boolean insertStock(Requisition request) {
        boolean state = false;
        try {
            ps = con.prepareStatement("INSERT INTO `requisition`( `r_date`, `pr_id`, `pr_qty`, `s_id`) VALUES (?,?,?,?)");

            ps.setString(1, request.getRequisition_date());
            ps.setInt(2, request.getProduct_Id());
            ps.setInt(3, request.getQuantity());
            ps.setInt(4, request.getUserId());
            if (ps.executeUpdate() > 0) {
                state = true;
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return state;
    }

}
