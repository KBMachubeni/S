/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DATA_ACCESS_LAYER;

import java.sql.*;

/**
 *
 * @author Karabo Machubeni
 */
public class DBConnection {

    private static DBConnection jdbc;

    private DBConnection() {
    }

    public static DBConnection getInstance() {
        if (jdbc == null) {
            jdbc = new DBConnection();
        }
        return jdbc;
    }

    public static Connection getConnection() {

        Connection connect = null;
        String url = "jdbc:mysql://localhost:3306/stationery?allowMultiQueries=true&rewriteBatchedStatements=true";

        try {
            Class.forName("com.mysql.jdbc.Driver");

            connect = DriverManager.getConnection(url, "root", "");
            //PROOF FOR CUSTOM EXCEPTION
            //  connect = null;
            if (connect != null) {
                System.out.println("DB OPEN!!!");
            } else {
                throw new CustomException("NO CONNECTECTION ESTABLISHED");
            }

        } catch (ClassNotFoundException | SQLException | CustomException ex) {
            System.out.println(ex.getMessage());
        }
        return connect;
    }

    PreparedStatement prepareStatement(String insert_into_orderor_date_pr_id_pr_qty_a_i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
