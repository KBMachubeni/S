package DATA_ACCESS_LAYER;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import BUSINESS_LOGIC_LAYER.Faculty;
import BUSINESS_LOGIC_LAYER.QueryOps;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Karabo Machubeni
 */
public class UserDataHandler implements QueryOps {

    static Connection con = DBConnection.getConnection();
    static PreparedStatement ps = null;
    public static String CURRENT_USER = null;

    public static boolean Login(String username, String password) {
        boolean state = false;
        try {
            ps = con.prepareStatement("SELECT * FROM `faculty` WHERE `stuff_username`= ? and `stuff_password`= ?");
            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                state = true;
                CURRENT_USER = username.toString();

            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return state;
    }

    public static List<Faculty> selectEmployees() {
        List<Faculty> employees = new ArrayList();
        try {
            ps = con.prepareStatement("SELECT  `stuff_name`, `stuff_type`, `stuff_location`, `stuff_deptname`, `stuff_contact`,`status` FROM `faculty`");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Faculty faculty = new Faculty(rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(1), rs.getString(5), rs.getString(6));
                employees.add(faculty);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return employees;
    }

    public static List<Faculty> selectByLocation(String location) {
        List<Faculty> employees = new ArrayList();
        try {
            ps = con.prepareStatement("SELECT  `stuff_name`, `stuff_type`, `stuff_location`, `stuff_deptname`, `stuff_contact`,`status` FROM `faculty` where `stuff_location`=? ");
            ps.setString(1, location);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Faculty faculty = new Faculty(rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(1), rs.getString(5), rs.getString(6));
                employees.add(faculty);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return employees;
    }

    @Override
    public boolean deleteEmployee(Faculty faculty) {
        boolean state = false;
        try {
            ps = con.prepareStatement("DELETE FROM `faculty` WHERE `stuff_id`=?");
            ps.setInt(1, faculty.getEmployeeid());
            if (ps.executeUpdate() > 0) {
                state = true;
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return state;
    }

    @Override
    public boolean insertEmployeee(Faculty faculty) {
        boolean state = false;
        try {
            ps = con.prepareStatement("INSERT INTO `faculty`(`stuff_name`, `stuff_type`, `stuff_location`, `stuff_deptname`, `stuff_contact`, `stuff_username`, `stuff_password`,`status`) VALUES (?,?,?,?,?,?,?,?) ");

            ps.setString(1, faculty.getName());
            ps.setString(2, faculty.getStuff_type());
            ps.setString(3, faculty.getStuff_location());
            ps.setString(4, faculty.getDept_name());
            ps.setString(5, faculty.getContact());
            ps.setString(6, faculty.getUsername());
            ps.setString(7, faculty.getPassword());
            ps.setString(8, faculty.getStatus());

            if (ps.executeUpdate() > 0) {
                state = true;
                CURRENT_USER = String.valueOf(faculty.getEmployeeid());
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return state;
    }

    @Override
    public boolean UpdateEmployee(Faculty faculty) {

        boolean state = false;
        try {
            ps = con.prepareStatement("UPDATE `faculty` SET `stuff_name`=?,`stuff_type`=?,`stuff_location`=?,`stuff_deptname`=?,`stuff_contact`=?,`status`=? WHERE `stuff_id`= ?");
            ps.setString(1, faculty.getName());
            ps.setString(2, faculty.getStuff_type());
            ps.setString(3, faculty.getStuff_location());
            ps.setString(4, faculty.getDept_name());
            ps.setString(5, faculty.getContact());
            ps.setString(6, faculty.getStatus());
//            ps.setString(7, faculty.getPassword());
            ps.setInt(7, faculty.getEmployeeid());
            if (ps.executeUpdate() > 0) {
                state = true;
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());

        }

        return state;
    }

    public static List<Faculty> selectEmployeesById(int id) {
        List<Faculty> employees = new ArrayList();
        try {
            ps = con.prepareStatement("SELECT  `stuff_name`, `stuff_type`, `stuff_location`, `stuff_deptname`, `stuff_contact`, `stuff_username`, `stuff_password` FROM `faculty` WHERE `stuff_id`=?");
          ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Faculty faculty = new Faculty(rs.getString(2), rs.getString(3),rs.getString(4), rs.getString(1), rs.getString(6), rs.getString(7), rs.getString(5));
                employees.add(faculty);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return employees;
    }

}
