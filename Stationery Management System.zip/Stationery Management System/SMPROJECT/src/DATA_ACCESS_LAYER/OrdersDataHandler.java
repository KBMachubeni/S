/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DATA_ACCESS_LAYER;

import BUSINESS_LOGIC_LAYER.Orders;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Karabo Machubeni
 */
public class OrdersDataHandler {

    DBConnection dbc= DBConnection.getInstance();
   static Connection con = DBConnection.getConnection();
    static PreparedStatement ps = null;
    public static String CURRENT_USER = null;

    public static boolean insertOrder(Orders order) {
        boolean state = false;
        try {
            ps = con.prepareStatement("INSERT INTO `order`(`or_date`, `pr_id`, `pr_qty`, `a_id`, `s_id`, `sup_id`) VALUES (?,?,?,?,?,?)");

            ps.setString(1, order.getOrder_date());
            ps.setInt(2, order.getProduct_Id());
            ps.setInt(3, order.getQuantity());
            ps.setInt(4, order.getAdmin_id());
            ps.setInt(5, order.getStaff_id());
            ps.setInt(6, order.getSupplierid());
            if (ps.executeUpdate() > 0) {
                state = true;
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return state;
    }
    
    
     public static List<Orders> selectOrders() {
        List<Orders> orderList = new ArrayList();
        try {
            ps = con.prepareStatement("SELECT `or_id`, `or_date`, `pr_id`, `pr_qty`, `a_id`, `s_id`, `sup_id` FROM `order` ");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
            Orders order= new Orders(rs.getInt(1),rs.getString(2),rs.getInt(7), rs.getInt(6),rs.getInt(5),rs.getInt(3),rs.getInt(4));
                orderList.add(order);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return orderList;
    }

}
