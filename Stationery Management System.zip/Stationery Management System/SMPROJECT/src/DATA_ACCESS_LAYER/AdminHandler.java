/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DATA_ACCESS_LAYER;

import BUSINESS_LOGIC_LAYER.Administrator;
import static DATA_ACCESS_LAYER.UserDataHandler.ps;
import DATA_ACCESS_LAYER.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Karabo Machubeni
 */
public class AdminHandler {
  
    static Connection con = DBConnection.getConnection();
    static PreparedStatement ps = null;
    
    
     public static boolean Login(String username, String password) {
        boolean state = false;
        try {
            ps = con.prepareStatement("Select * from administrator where a_username = ? and a_password = ?");
            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                state = true;

            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return state;
    }
  
     public static boolean insertEmployeee(Administrator admin) {
        boolean state = false;
        try {
            ps = con.prepareStatement("INSERT INTO `administrator`( `a_name`, `a_username`, `a_password`, `a_contact`, `salt`, `securePass`) VALUES (?,?,?,?,?,?) ");

            ps.setString(1, admin.getName());
            ps.setString(2, admin.getUsername());
            ps.setString(3, admin.getPassword());
            ps.setString(4, admin.getContact());
            ps.setString(5, admin.getSalt());
            ps.setString(6, admin.getSecurepass());
          
            if (ps.executeUpdate() > 0) {
                state = true;
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return state;
    }

    
}
