/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BUSINESS_LOGIC_LAYER;

/**
 *
 * @author Karabo Machubeni
 */
public interface QueryOps {
    
    public boolean insertEmployeee(Faculty faculty);
    
    public boolean UpdateEmployee(Faculty faculty);
    
   public boolean deleteEmployee(Faculty faculty);
        
    
}
