/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BUSINESS_LOGIC_LAYER;

import java.util.Comparator;

/**
 *
 * @author Karabo Machubeni
 */
public class SortByName implements Comparator<Products> {

    @Override
    public int compare(Products t, Products t1) {
        return t.getProduct_Name().compareTo(t1.getProduct_Name());
    }

}
