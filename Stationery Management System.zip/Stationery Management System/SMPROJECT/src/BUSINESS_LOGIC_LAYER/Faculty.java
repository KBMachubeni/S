/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BUSINESS_LOGIC_LAYER;

/**
 *
 * @author Karabo Machubeni
 */
public class Faculty extends Employee {

    String stuff_type;
    String stuff_location;
    String dept_name;

    public Faculty(String stuff_type, String stuff_location, String dept_name, String name, String username, String password, String contact) {
        super(name, username, password, contact);
        this.stuff_type = stuff_type;
        this.stuff_location = stuff_location;
        this.dept_name = dept_name;
    }

    public Faculty(String stuff_type, String stuff_location, String dept_name, String name, String username, String password, String contact, String status) {
        super(name, username, password, contact, status);
        this.stuff_type = stuff_type;
        this.stuff_location = stuff_location;
        this.dept_name = dept_name;
    }


    

    public Faculty(int employeeid, String name, String username, String password, String contact, String stuff_type, String stuff_location, String dept_name) {
        super(employeeid, name, username, password, contact);
        this.stuff_type = stuff_type;
        this.stuff_location = stuff_location;
        this.dept_name = dept_name;
    }

    public Faculty(String stuff_type, String stuff_location, String dept_name, String name, String contact, String status) {
        super(name, contact, status);
        this.stuff_type = stuff_type;
        this.stuff_location = stuff_location;
        this.dept_name = dept_name;
    }

    public Faculty(String stuff_type, String stuff_location, String dept_name, int employeeid, String name, String contact, String status) {
        super(employeeid, name, contact, status);
        this.stuff_type = stuff_type;
        this.stuff_location = stuff_location;
        this.dept_name = dept_name;
    }

    
    public Faculty(String name, String contact, String stuff_type, String stuff_location, String dept_name) {
        super( name, contact);

        this.stuff_type = stuff_type;
        this.stuff_location = stuff_location;
        this.dept_name = dept_name;
    }

    public Faculty(int employeeid) {
        super(employeeid);
    }

 

    
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStuff_type() {
        return stuff_type;
    }

    public void setStuff_type(String stuff_type) {
        this.stuff_type = stuff_type;
    }

    public String getStuff_location() {
        return stuff_location;
    }

    public void setStuff_location(String stuff_location) {
        this.stuff_location = stuff_location;
    }

    public String getDept_name() {
        return dept_name;
    }

    public void setDept_name(String dept_name) {
        this.dept_name = dept_name;
    }

}
