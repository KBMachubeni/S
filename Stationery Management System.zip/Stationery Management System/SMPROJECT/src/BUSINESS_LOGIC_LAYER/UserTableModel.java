/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BUSINESS_LOGIC_LAYER;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.*;

/**
 *
 * @author Karabo Machubeni
 */
public class UserTableModel extends AbstractTableModel {

    List<Faculty> user = new ArrayList();

    @Override
    public int getRowCount() {
        return this.user.size();
    }

    @Override
    public int getColumnCount() {
        return 6;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Faculty users = getUser(rowIndex);
        switch (columnIndex) {
            
            case 0:
                return users.getName();
            case 1:
                return users.getStuff_type();
            case 2:
                return users.getStuff_location();
            case 3:
                return users.getDept_name();
            case 4:
                return users.getContact();
            case 5:
                return users.getStatus();
            default:
                return null;
        }

    }

    @Override
    public String getColumnName(int columnIndex) {
        switch (columnIndex) {
            case 0:
                return "Name";
            case 1:
                return "Staff Type";
            case 2:
                return "Campus Location";
            case 3:
                return "Department";
            case 4:
                return "Contact Details";
            case 5:
                return "Status";
            default:
                return null;
        }
    }

    public void insertUser(Faculty user) {
        this.user.add(user);
        fireTableDataChanged();
    }
        
        public void deleteUser(Faculty user){
            this.user.remove(user);
            fireTableDataChanged();
        }

//        public void updateUser(Faculty user){
//            this.user.set(i, user)
//            fireTableDataChanged();
//        }
    public UserTableModel(List<Faculty> user) {
        this.user = user;
    }

    public Faculty getUser(int index) {
        return this.user.get(index);
    }

}
