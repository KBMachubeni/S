/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BUSINESS_LOGIC_LAYER;

import BUSINESS_LOGIC_LAYER.Employee;

/**
 *
 * @author Karabo Machubeni
 */
public class Administrator extends Employee{

    private String salt;
    private String securepass;
        
    public Administrator(int employeeid, String name, String username, String password, String contact) {
        super(employeeid, name, username, password, contact);
    }

    public Administrator(String salt, String securepass, String name, String username, String password, String contact) {
        super(name, username, password, contact);
        this.salt = salt;
        this.securepass = securepass;
    }

    

    public String getSalt() {
        return salt;
    }

    public void setSalt(String salt) {
        this.salt = salt;
    }

    public String getSecurepass() {
        return securepass;
    }

    public void setSecurepass(String securepass) {
        this.securepass = securepass;
    }
    
    
    
}
