/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BUSINESS_LOGIC_LAYER;

/**
 *
 * @author Karabo Machubeni
 */
public class Products {

    private int product_Id;
    private String product_Name;
    private double product_Amount;
    private int quantity;
    private String category;

    public Products() {
    }

    
    
    public Products(int product_Id, String product_Name, double product_Amount, int quantity, String category) {
        this.product_Id = product_Id;
        this.product_Name = product_Name;
        this.product_Amount = product_Amount;
        this.quantity = quantity;
        this.category = category;
    }

    public Products(int product_Id, int quantity) {
        this.product_Id = product_Id;
        this.quantity = quantity;
    }

    
    public Products(int product_Id, String product_Name, double product_Amount, String category) {
        this.product_Id = product_Id;
        this.product_Name = product_Name;
        this.product_Amount = product_Amount;
        this.category = category;
    }

    
    
    public Products(String product_Name, double product_Amount, int quantity, String category) {
        this.product_Name = product_Name;
        this.product_Amount = product_Amount;
        this.quantity = quantity;
        this.category = category;
    }

    
    public int getProduct_Id() {
        return product_Id;
    }

    public void setProduct_Id(int product_Id) {
        this.product_Id = product_Id;
    }

    public String getProduct_Name() {
        return product_Name;
    }

    public void setProduct_Name(String product_Name) {
        this.product_Name = product_Name;
    }

    public double getProduct_Amount() {
        return product_Amount;
    }

    public void setProduct_Amount(double product_Amount) {
        this.product_Amount = product_Amount;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    
  

}
