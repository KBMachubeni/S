/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BUSINESS_LOGIC_LAYER;

/**
 *
 * @author Karabo Machubeni
 */
public class Orders  extends Products{
    
    int order_id;
    String order_date;
    int supplierid;
    int staff_id;
    int admin_id;

    public Orders(int order_id, String order_date, int supplierid, int staff_id, int admin_id, int product_Id, int quantity) {
        super(product_Id, quantity);
        this.order_id = order_id;
        this.order_date = order_date;
        this.supplierid = supplierid;
        this.staff_id = staff_id;
        this.admin_id = admin_id;
    }

    public Orders(String order_date, int supplierid, int staff_id, int admin_id, int product_Id, int quantity) {
        super(product_Id, quantity);
        this.order_date = order_date;
        this.supplierid = supplierid;
        this.staff_id = staff_id;
        this.admin_id = admin_id;
    }

    
    
    public int getSupplierid() {
        return supplierid;
    }

    public void setSupplierid(int supplierid) {
        this.supplierid = supplierid;
    }

    public int getStaff_id() {
        return staff_id;
    }

    public void setStaff_id(int staff_id) {
        this.staff_id = staff_id;
    }

    public int getAdmin_id() {
        return admin_id;
    }

    public void setAdmin_id(int admin_id) {
        this.admin_id = admin_id;
    }
 

    public int getOrder_id() {
        return order_id;
    }

    public void setOrder_id(int order_id) {
        this.order_id = order_id;
    }

    public String getOrder_date() {
        return order_date;
    }

    public void setOrder_date(String order_date) {
        this.order_date = order_date;
    }
    
    
}
