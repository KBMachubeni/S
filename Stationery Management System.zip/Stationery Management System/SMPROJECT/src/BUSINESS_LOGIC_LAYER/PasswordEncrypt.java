/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BUSINESS_LOGIC_LAYER;

import DATA_ACCESS_LAYER.DBConnection;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Base64;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 *
 * @author Karabo Machubeni
 */
public class PasswordEncrypt {
    static Connection con = DBConnection.getConnection();
    static PreparedStatement ps = null;

    private static final Random RANDOM = new SecureRandom();
    private static final String ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    private static final int ITERATIONS = 10000;
    private static final int KEY_LENGTH = 256;

    public static String getSalt(int length) {
        StringBuilder returnValue = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            returnValue.append(ALPHABET.charAt(RANDOM.nextInt(ALPHABET.length())));
        }
        return new String(returnValue);
    }

    public static byte[] hash(char[] password, byte[] salt)  {
        PBEKeySpec spec = new PBEKeySpec(password, salt, ITERATIONS, KEY_LENGTH);
        Arrays.fill(password, Character.MIN_VALUE);
        try {
                SecretKeyFactory skf= SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
                return skf.generateSecret(spec).getEncoded();
        } catch (NoSuchAlgorithmException |InvalidKeySpecException e) {
            throw new AssertionError("ERROR WHILE HASHING PASSWORD:"+ e.getMessage(),e);
        }finally{
            spec.clearPassword();
        }
    }
    
    
    public static String generateSecurePassword(String password,String salt){
     
        String returnValue=null;
        byte[] securePassword= hash(password.toCharArray(), salt.getBytes());
        returnValue= Base64.getEncoder().encodeToString(securePassword);
        return returnValue;
    }

    
    public static boolean verifyUserPassword(String providedPassword,String securedPassword, String salt){
        boolean returnValue= false;
        String newSecurePassword= generateSecurePassword(providedPassword, salt);
        returnValue= newSecurePassword.equalsIgnoreCase(securedPassword);
        return returnValue;
    }
    
    
    public static boolean InsertEncrpyt(String salt,String securepass)
    {
        boolean state= false;
        try {
            ps= con.prepareStatement("INSERT INTO `encrypted`(`salt`, `securepass`) VALUES (?,?)");
            ps.setString(1, salt);
            ps.setString(2, securepass);
            if (ps.executeUpdate()>0) {
                state= true;
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return state;
    }
}
