/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BUSINESS_LOGIC_LAYER;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.*;

/**
 *
 * @author Karabo Machubeni
 */
public class ProductsTableModel extends AbstractTableModel {

    List<Products> stocklist = new ArrayList();

    @Override
    public int getRowCount() {
        return this.stocklist.size();
    }

    @Override
    public int getColumnCount() {
        return 4;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Products product = getStock(rowIndex);
        switch (columnIndex) {
            case 0:
                return product.getCategory();
            case 1:
                return product.getProduct_Name();
            case 2:
                return product.getProduct_Amount();
            case 3:
                return product.getQuantity();
            default:
                return null;
        }

    }

    @Override
    public String getColumnName(int columnIndex) {
        switch (columnIndex) {
            case 0:
                return "Category Name";
            case 1:
                return "Product Name";
            case 2:
                return "Price";
            case 3:
                return "Quantity";
            default:
                return null;
        }
    }

    public void insertStock(Products product) {
        this.stocklist.add(product);
        fireTableDataChanged();
    }

    public void deleteStock(Products product) {
        this.stocklist.remove(product);
        fireTableDataChanged();
    }

    public ProductsTableModel(List<Products> product) {
        this.stocklist = product;
    }

    public Products getStock(int index) {
        return this.stocklist.get(index);
    }

}
