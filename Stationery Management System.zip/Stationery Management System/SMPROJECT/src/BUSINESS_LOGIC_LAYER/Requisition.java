/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BUSINESS_LOGIC_LAYER;

/**
 *
 * @author Karabo Machubeni
 */
public class Requisition extends Products {

    private int requisition_id;
    private String requisition_date;
    private int userId;

    public Requisition(int requisition_id) {
        super();
        this.requisition_id = requisition_id;
    }

    
    public int getRequisition_id() {
        return requisition_id;
    }

    public void setRequisition_id(int requisition_id) {
        this.requisition_id = requisition_id;
    }

    public String getRequisition_date() {
        return requisition_date;
    }

    public void setRequisition_date(String requisition_date) {
        this.requisition_date = requisition_date;
    }

    public Requisition(String requisition_date, int userId, int product_Id, int quantity) {
        super(product_Id, quantity);
        this.requisition_date = requisition_date;
        this.userId = userId;
    }

    
    public Requisition(int requisition_id, String requisition_date, int product_Id, int quantity) {
        super(product_Id, quantity);
        this.requisition_id = requisition_id;
        this.requisition_date = requisition_date;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    
    public Requisition(int requisition_id, String requisition_date,int userId, int product_Id, int quantity) {
        super(product_Id, quantity);
        this.requisition_id = requisition_id;
        this.requisition_date = requisition_date;
        this.userId=userId;
    }

}
