/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BUSINESS_LOGIC_LAYER;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Karabo Machubeni
 */
public class OrderTableModel extends AbstractTableModel {

    List<Orders> requestlist = new ArrayList();

    @Override
    public int getRowCount() {
        return this.requestlist.size();
    }

    @Override
    public int getColumnCount() {
        return 6;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Orders order = getStock(rowIndex);
        switch (columnIndex) {
            case 0:
                return order.getOrder_id();
            case 1:
                return order.getOrder_date();
            case 2:
                return order.getProduct_Id();
            case 3:
                return order.getQuantity();
            case 4:
                return order.getAdmin_id();
            case 5:
                return order.getSupplierid();
            default:
                return null;
        }

    }

    @Override
    public String getColumnName(int columnIndex) {
        switch (columnIndex) {
            case 0:
                return "ORDER ID";
            case 1:
                return "ORDER DATE";
            case 2:
                return "PRODUCT ID";
            case 3:
                return "QUANTITY";
            case 4:
                return "ADMIN ID";
            case 5:
                return "SUPPLIER ID";
            default:
                return null;
        }
    }

    public void insertStock(Orders orders) {
        this.requestlist.add(orders);
        fireTableDataChanged();
    }

    public void deleteStock(Orders orders) {
        this.requestlist.remove(orders);
        fireTableDataChanged();
    }

    public OrderTableModel(List<Orders> orders) {
        this.requestlist = orders;
    }

    public Orders getStock(int index) {
        return this.requestlist.get(index);
    }

}
