/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BUSINESS_LOGIC_LAYER;

import PRESENTATION_LAYER.Login;

/**
 *
 * @author Karabo Machubeni
 */
public class ThreadClass implements Runnable {

    @Override
    public void run() {
        Login l = new Login();
        l.setVisible(true);
    }

}
