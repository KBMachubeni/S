/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BUSINESS_LOGIC_LAYER;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Karabo Machubeni
 */
public class RequestTableModel extends AbstractTableModel {


    List<Requisition> requestlist = new ArrayList();

    @Override
    public int getRowCount() {
        return this.requestlist.size();
    }

    @Override
    public int getColumnCount() {
        return 5;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
       Requisition requisition= getStock(rowIndex);
       
        switch (columnIndex) {
            case 0:
                return  requisition.getRequisition_date();
            case 1:
                return requisition.getRequisition_id();
            case 2:
                return requisition.getProduct_Id();
            case 3:
                return requisition.getQuantity();
            case 4:
                return requisition.getUserId();
            default:
                return null;
        }

    }

    @Override
    public String getColumnName(int columnIndex) {
        switch (columnIndex) {
            case 0:
                return "Date";
            case 1:
                return "Requisition Id";
            case 2:
                return "Product Id";
            case 3:
                return "Quantity";
            case 4:
                return "Required By";
            default:
                return null;
        }
    }

    public void insertStock(Requisition request) {
        this.requestlist.add(request);
        fireTableDataChanged();
    }

    public void deleteStock(Requisition request) {
        this.requestlist.remove(request);
        fireTableDataChanged();
    }

    public RequestTableModel(List<Requisition> request) {
        this.requestlist = request;
    }

    public Requisition getStock(int index) {
        return this.requestlist.get(index);
    }

}


