/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BUSINESS_LOGIC_LAYER;

/**
 *
 * @author Karabo Machubeni
 */
public class Employee {
    
    int employeeid;
    String name;
    String username;
    String password;
    String contact;
    String status;

    public Employee(int employeeid) {
        this.employeeid = employeeid;
    }

    
    public Employee(String name, String username, String password, String contact, String status) {
        this.name = name;
        this.username = username;
        this.password = password;
        this.contact = contact;
        this.status = status;
    }

    public Employee(String name, String contact, String status) {
        this.name = name;
        this.contact = contact;
        this.status = status;
    }

    public Employee(int employeeid, String name, String contact, String status) {
        this.employeeid = employeeid;
        this.name = name;
        this.contact = contact;
        this.status = status;
    }
    
    

    public Employee(String name, String username, String password, String contact) {
        this.name = name;
        this.username = username;
        this.password = password;
        this.contact = contact;
    }

    

    
    public Employee(int employeeid, String name, String username, String password, String contact) {
        this.employeeid = employeeid;
        this.name = name;
        this.username = username;
        this.password = password;
        this.contact = contact;
    }

    public Employee(String name, String contact) {
       
        this.name = name;
        this.contact = contact;
    }
    
    
    

    public int getEmployeeid() {
        return employeeid;
    }

    public void setEmployeeid(int employeeid) {
        this.employeeid = employeeid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    @Override
    public String toString() {
        return "Employee{" + "employeeid=" + employeeid + ", name=" + name + ", username=" + username + ", password=" + password + ", contact=" + contact + '}';
    }
    
    
    
    
}
