/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sminterface;

import java.io.Serializable;
import java.util.Objects;

/**
 *
 * @author Karabo Machubeni
 */
public class Supplier implements Serializable {
    
    int supplier_Id;
    String supplier_name;
    String supplier_Contact;
    String supplier_Address;

    public Supplier(int supplier_Id, String supplier_name, String supplier_Contact, String supplier_Address) {
        this.supplier_Id = supplier_Id;
        this.supplier_name = supplier_name;
        this.supplier_Contact = supplier_Contact;
        this.supplier_Address = supplier_Address;
    }

    public Supplier(String supplier_name, String supplier_Contact, String supplier_Address) {
        this.supplier_name = supplier_name;
        this.supplier_Contact = supplier_Contact;
        this.supplier_Address = supplier_Address;
    }
    
    

    public int getSupplier_Id() {
        return supplier_Id;
    }

    public void setSupplier_Id(int supplier_Id) {
        this.supplier_Id = supplier_Id;
    }

    public String getSupplier_name() {
        return supplier_name;
    }

    public void setSupplier_name(String supplier_name) {
        this.supplier_name = supplier_name;
    }

    public String getSupplier_Contact() {
        return supplier_Contact;
    }

    public void setSupplier_Contact(String supplier_Contact) {
        this.supplier_Contact = supplier_Contact;
    }

    public String getSupplier_Address() {
        return supplier_Address;
    }

    public void setSupplier_Address(String supplier_Address) {
        this.supplier_Address = supplier_Address;
    }

    @Override
    public String toString() {
        return "Supplier{" + "supplier_Id=" + supplier_Id + ", supplier_name=" + supplier_name + ", supplier_Contact=" + supplier_Contact + ", supplier_Address=" + supplier_Address + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 73 * hash + this.supplier_Id;
        hash = 73 * hash + Objects.hashCode(this.supplier_name);
        hash = 73 * hash + Objects.hashCode(this.supplier_Contact);
        hash = 73 * hash + Objects.hashCode(this.supplier_Address);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Supplier other = (Supplier) obj;
        if (this.supplier_Id != other.supplier_Id) {
            return false;
        }
        if (!Objects.equals(this.supplier_name, other.supplier_name)) {
            return false;
        }
        if (!Objects.equals(this.supplier_Contact, other.supplier_Contact)) {
            return false;
        }
        if (!Objects.equals(this.supplier_Address, other.supplier_Address)) {
            return false;
        }
        return true;
    }
    
    
    
    
    
}
