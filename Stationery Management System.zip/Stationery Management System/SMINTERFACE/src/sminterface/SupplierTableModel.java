/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sminterface;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;
import sminterface.Supplier;

/**
 *
 * @author Karabo Machubeni
 */
public class SupplierTableModel extends AbstractTableModel{
    
   


    List<Supplier> supplierlist = new ArrayList();

    @Override
    public int getRowCount() {
        return this.supplierlist.size();
    }

    @Override
    public int getColumnCount() {
        return 3;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
       Supplier supplier= getSupplier(rowIndex);
       
        switch (columnIndex) {
            case 0:
                return  supplier.getSupplier_name();
            case 1:
                return supplier.getSupplier_Contact();
            case 2:
                return supplier.getSupplier_Address();
            default:
                return null;
        }

    }

    @Override
    public String getColumnName(int columnIndex) {
        switch (columnIndex) {
            case 0:
                return "NAME";
            case 1:
                return "CONTACT";
            case 2:
                return "ADDRESS";
            default:
                return null;
        }
    }

    public void insertSupplier(Supplier supplier) {
        this.supplierlist.add(supplier);
        fireTableDataChanged();
    }

    public void deleteSupplier(Supplier supplier) {
        this.supplierlist.remove(supplier);
        fireTableDataChanged();
    }

    public SupplierTableModel(List<Supplier> supplier) {
        this.supplierlist = supplier;
    }

    public Supplier getSupplier(int index) {
        return this.supplierlist.get(index);
    }

}
